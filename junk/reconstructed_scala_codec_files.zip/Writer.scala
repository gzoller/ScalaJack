package co.blocke.scalajack.json.writing

import scala.quoted.*
import co.blocke.scala_reflection.reflect.rtypeRefs.*
import co.blocke.scala_reflection.{RTypeRef, TypedName}

object Writer:
  def genWriterFor[W](ctx: CodecBuildContext, cfg: SJConfig, in: Expr[W], ref: RTypeRef[W], out: Expr[JsonOutput])(using Type[W], Quotes): Expr[Unit] =
    import quotes.reflect.*
    ref match
      case _: StringRef => '{ $out.valueEscaped($in.toString) }
      case _: IntRef    => '{ $out.value($in.asInstanceOf[Int]) }
      case c: ScalaClassRef[?] =>
        val fields = c.fields.map { field =>
          val nameExpr = Expr(field.name)
          val access = Select.unique(in.asTerm, field.name).asExpr
          val writer = genWriterFor(ctx, cfg, access, field.fieldRef.asInstanceOf, out)(using Type.of(using quotes)(field.fieldRef.refType))
          '{ $out.label($nameExpr); $writer }
        }
        Expr.block('{ $out.startObject() } +: fields :+ '{ $out.endObject() }, '{ () })
      case _ =>
        quotes.reflect.report.error(s"Unsupported type: $ref"); '{ () }
