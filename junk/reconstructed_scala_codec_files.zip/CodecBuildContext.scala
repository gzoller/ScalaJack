package co.blocke.scalajack.json

import scala.quoted.*
import scala.collection.mutable

class CodecBuildContext(using val quotes: Quotes):
  val generatedWriters: mutable.Map[String, Expr[(Any, JsonOutput) => Unit]] = mutable.Map.empty
